﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class FaseDeGrupos : Partido
    {
        #region Atributos
        public string NombreDelGrupo { get; set; }
        #endregion

        #region Constructores
        public FaseDeGrupos()
        {
            Id = UltimoId;
            UltimoId++;
        }

        public FaseDeGrupos(string nombreDelGrupo, Seleccion seleccion1, Seleccion seleccion2, DateTime fechaYHoraDelPartido, bool finalizado, string resultadoDelPartido): base(seleccion1, seleccion2, fechaYHoraDelPartido, finalizado, resultadoDelPartido)
        {
            Id = UltimoId;
            UltimoId++;
            NombreDelGrupo = nombreDelGrupo;
        }
        #endregion

        #region Metodos
        // Metodo abstract que aun no se usa, para calcular el resultado del partido
        public override string CalcularResultado()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return "Grupo " + NombreDelGrupo + "\n" + base.ToString();
        }

        public override bool Equals(object obj)
        {
            return obj is FaseDeGrupos grupos &&
                   base.Equals(obj) &&
                   EqualityComparer<Seleccion>.Default.Equals(Seleccion1, grupos.Seleccion1) &&
                   EqualityComparer<Seleccion>.Default.Equals(Seleccion2, grupos.Seleccion2) &&
                   FechaYhoraDelPartido == grupos.FechaYhoraDelPartido;
        }

        #endregion
    }
}
