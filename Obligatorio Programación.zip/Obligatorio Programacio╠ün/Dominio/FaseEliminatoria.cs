﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public class FaseEliminatoria : Partido
    {
        #region Atributos
        public bool Alargue { get; set; }
        public bool Penales { get; set; }
        public Etapa Etapa { get; set; }
        #endregion

        #region Constructores
        public FaseEliminatoria()
        {
            Id = UltimoId;
            UltimoId++;
        }

        public FaseEliminatoria(bool alargue, bool penales, Etapa etapa, Seleccion seleccion1, Seleccion seleccion2, DateTime fechaYhoraDelPartido, bool finalizado, string resultadoDelPartido): base(seleccion1, seleccion2, fechaYhoraDelPartido, finalizado, resultadoDelPartido)
        {
            Id = UltimoId;
            UltimoId++;
            Alargue = alargue;
            Penales = penales;
            Etapa = etapa;
        }
        #endregion

        #region Metodos
        // Metodo abstract que aun no se usa, para calcular el resultado del partido
        public override string CalcularResultado()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return "Etapa: " + Etapa + "\n" + base.ToString();
        }
 
        /// <summary>
        /// Metodo sobreescrito para Agregar una incidencia con su coprrespondiente validación
        /// </summary>
        /// <param name="unaIncidencia"></param>
        public override void AddIncidencia(Incidencia unaIncidencia)
        {
            bool existe = false;

            if (base.Finalizado)
            {
                throw new Exception("El partido ya finalizó, no puede agregar incidencias");
            }
            else
            {
                unaIncidencia.Validar();
                foreach (Jugador j1 in Seleccion1.GetJugadores())
                {
                    if (j1.NombreCompleto == unaIncidencia.UnJugador.NombreCompleto)
                    {
                        existe = true;
                    }
                }
                if (!existe)
                {
                    foreach (Jugador j2 in Seleccion2.GetJugadores())
                    {
                        if (j2.NombreCompleto == unaIncidencia.UnJugador.NombreCompleto)
                        {
                            existe = true;
                        }
                    }
                }
                try
                {
                    if (existe)
                    {
                        if (Penales == true)
                        {
                            unaIncidencia.Validar();
                            base.GetIncidencias().Add(unaIncidencia);
                        }
                        else
                        {
                            if (unaIncidencia.Minuto >= 0)
                            {
                                unaIncidencia.Validar();
                                base.GetIncidencias().Add(unaIncidencia);
                            }
                            else
                            {
                                throw new Exception("Minuto incorrecto");
                            }
                        }
                    }
                    else
                    {
                        throw new Exception("El jugador agregado no pertenece a los seleccionados del partido");
                    }
                }
                catch (Exception e)
                {
                    throw new Exception(e.Message);
                }
            }
        }

        public override bool Equals(object obj)
        {
            return obj is FaseEliminatoria eliminatoria &&
                   base.Equals(obj) &&
                   EqualityComparer<Seleccion>.Default.Equals(Seleccion1, eliminatoria.Seleccion1) &&
                   EqualityComparer<Seleccion>.Default.Equals(Seleccion2, eliminatoria.Seleccion2) &&
                   FechaYhoraDelPartido == eliminatoria.FechaYhoraDelPartido;
        }
        #endregion
    }
}
