﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public enum Etapa
    {
        Octavos = 8,
        Cuartos = 4,
        Semifinal = 2,
        Final = 1
    }
}
