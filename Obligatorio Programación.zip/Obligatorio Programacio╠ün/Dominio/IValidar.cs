﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dominio
{
    public interface IValidar
    {
        public void Validar();

        public string ToString();
    }
}
